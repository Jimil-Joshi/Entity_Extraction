import os
import uuid
import re
from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain.chains import ConversationalRetrievalChain
from langchain_openai import ChatOpenAI
from langchain.callbacks import get_openai_callback


# Load environment variables from .env file
load_dotenv()

# Set the API key
api_key = os.getenv("OPENAI_API_KEY")

# Now you can use os.environ['OPENAI_API_KEY'] to access the API key in your script

def clean_text(text):
    # Remove special characters and newline characters using regular expressions
    cleaned_text = re.sub(r'[^\w\s]', '', text)
    cleaned_text = re.sub(r'\n', ' ', cleaned_text)
    return cleaned_text
def initialize_custom_conversational_chain(file_path, unique_id):
    # Set your OpenAI API key
    os.environ['OPENAI_API_KEY'] = api_key

    persist_directory = f'./data/dbfiles_{unique_id}'
    # Remove the existing persist directory if it exists


    # os.makedirs(persist_directory, exist_ok=True)
    # print("file_path", file_path)
    loader = PyPDFLoader(file_path)
    documents = loader.load()
    file_name = os.path.splitext(os.path.basename(file_path))[0]

    # Split documents
    text_splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=50)
    documents = text_splitter.split_documents(documents)
    # Clean the text content of each document's page_content
    for doc in documents:
        doc.page_content = clean_text(doc.page_content)
    # print("inititalising vectordb")
    # Create vector store
    vectordb = Chroma.from_documents(
        documents,
        embedding=OpenAIEmbeddings(),
        persist_directory= persist_directory
    )
    vectordb.persist()
    return vectordb
def create_quchain(vectordb):
    # Define the system message templateShraddha
    system_template = """
    Your role is customer support representative. 
    Your task is to refer the provided context and answer the user's question using the given context in 2-3 words, no more then 50words. 
    If the answer cannot be found in the context, simply provide output as "null", do not make the answer like 'The type of agreement mentioned in the given context is not specified' also if the query is as greetings (i.e.Hi, Hello,How are you?)simply state, "null".
    Please consider the synonyms of the question for example 'start date' can also be referred as 'effective date'.
    ---------------- {context}
    """
    # Create the chat prompt templates
    messages = [
        SystemMessagePromptTemplate.from_template(system_template),
        HumanMessagePromptTemplate.from_template("{question}")
    ]
    qa_prompt = ChatPromptTemplate.from_messages(messages)
    # Create conversational retrieval chain
    retriever = vectordb.as_retriever(search_kwargs={'k': 2})

    qa_chain = ConversationalRetrievalChain.from_llm(
        ChatOpenAI(temperature=0.2),
        retriever=retriever,
        return_source_documents=True,
        combine_docs_chain_kwargs={"prompt": qa_prompt}
    )
    return qa_chain


def custom_answer_query(query, qa_chain):
    chat_history = []
    # history_query = chat_history[-2:] if len(chat_history) >= 2 else chat_history[:]
        # If query is a list, process each element separately
    if isinstance(query, list):
        results_list = []
        for q, qa_chain in zip(query, qa_chain):
            results = qa_chain({'question': q, 'chat_history': chat_history})
            results_list.append(results)
            # print(results)

        answer_list = [res['answer'] for res in results_list]
        # print(answer_list)
        metadata_list = []
        for answer, results in zip(answer_list, results_list):
            if answer == "null":
                metadata_list.append('{Not found}')
            else:
                metadata = []
                for document in results['source_documents']:
                    metadata.append(document.metadata)
                metadata_list.append(metadata[0])

        return answer_list, metadata_list



def main(file_paths):
    unique_id = str(uuid.uuid4())

    query_fields = [
    "Legal agreement exist",
    "Contract owner",
    "Contract Reminders",
    "Contract Entered Date",
    "Contract Type",
    "Contract reviewer",
    "Third Party contract",
    "Contract Term Duration",
    "Internal review start date",
    "Third Party notification duration",
    "Expiration date",
    "Internal review duration",
    "Third party notification date",
    "Original Start Date",
    "Current Start Date",
    "Approved Budget",
    "Annual Contract Value",
    "Annual Contract increase",
    "Total Contract Value",
    "Termination fees",
    "Back Billing",
    "Future Purchase",
    "Late Fees",
    "Installation Payments",
    "Fee Disputes"
]

    data_list = [
        "String (Yes/No)",
        "String",
        "String",
        "Date (mm/dd/YYYY)",
        "String",
        "Integer",
        "String",
        "String (Days, Month, Year)",
        "Date (mm/dd/YYYY)",
        "String (Days, Month, Year)",
        "Date (mm/dd/YYYY)",
        "String (Days, Month, Year)",
        "Date (mm/dd/YYYY)",
        "Date (mm/dd/YYYY)",
        "Date (mm/dd/YYYY)",
        "Float",
        "Float",
        "String",
        "Float",
        "Float",
        "String",
        "String",
        "String",
        "String",
        "String"
    ]
    db_column_list = [
        "legal_agreement_exists",
        "owner_id",
        "contract_reminder",
        "contract_entered_date",
        "contract_type",
        "reviewer_id",
        "Thirdparty_contract",
        "contract_term_duration",
        "internal_review_start_date",
        "thirdparty_notification_term",
        "thirdparty_notification_term_duration",
        "expiration_date",
        "internal_review_term_duration",
        "thirdparty_notification_date",
        "original_start_date",
        "current_start_date",
        "approved_budget",
        "annual_contract_value",
        "annual_contract_increase",
        "total_contract_value",
        "termination_fees",
        "back_billing",
        "future_purchase",
        "late_fees",
        "installation_payments",
        "fee"
    ]
    results = {}
    vectordb = initialize_custom_conversational_chain(file_paths, unique_id)

    # Process queries in batches of 4
    batch_size = 4
    num_queries = len(query_fields)

    for start_index in range(0, num_queries, batch_size):
        end_index = start_index + batch_size
        batch_query_list = []
        batch_quchain_list = []

        for query_field, data_type in zip(query_fields[start_index:end_index], data_list[start_index:end_index]):
            qachain = create_quchain(vectordb)
            batch_quchain_list.append(qachain)
            # print("Query" + query_field, "datatype"+data_type)
            query = f"Extract answer for {query_field} if available, and reformat the information in {data_type} format"

            batch_query_list.append(query)



        answer, metadata = custom_answer_query(batch_query_list, batch_quchain_list)

        for db_query, a, m in zip(db_column_list[start_index:end_index], answer, metadata):
            if not isinstance(m, dict):
                m = {'metadata': m}

            results[db_query] = {"answer": a, "metadata": m}

            for key, value in results.items():
                # Check if 'metadata' key is present in the nested dictionary
                if 'metadata' in value and 'metadata' in value['metadata']:

                    # Replace {'metadata': 'Not found'} with {"metadata": "not_found"}
                    print(metadata)
                    if isinstance(value, dict) and 'page' in value and isinstance(value['page'], int):
                        value['page'] += 1
                    value['metadata'] = "not_found"

    return results


#
# file_paths = "/home/joshi/Downloads/Adobe General Terms of Use.pdf"
# print(main(file_paths))
