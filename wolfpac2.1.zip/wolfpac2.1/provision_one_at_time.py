import json
import os
import time
import uuid
from datetime import datetime

from dotenv import load_dotenv
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_openai import OpenAIEmbeddings
from langchain.chains import ConversationalRetrievalChain
from langchain_openai import ChatOpenAI

# Load environment variables from .env file
load_dotenv()

# Set the API key
api_key = os.getenv("OPENAI_API_KEY")

# Now you can use os.environ['OPENAI_API_KEY'] to access the API key in your script


def initialize_custom_conversational_chain(file_path, unique_id):
    # Set your OpenAI API key
    os.environ['OPENAI_API_KEY'] = api_key

    persist_directory = f'./data/dbfiles_{unique_id}'
    # Remove the existing persist directory if it exists


    # os.makedirs(persist_directory, exist_ok=True)
    # print("file_path", file_path)
    loader = PyPDFLoader(file_path)
    documents = loader.load()

    # Split documents
    text_splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=50)
    documents = text_splitter.split_documents(documents)
    # print("inititalising vectordb")
    # Create vector store
    vectordb = Chroma.from_documents(
        documents,
        embedding=OpenAIEmbeddings(),
        persist_directory= persist_directory
    )
    vectordb.persist()
    return vectordb
def create_quchain(vectordb):
    # Define the system message templateShraddha
    system_template = """
    Your role is customer support representative. 
    Your task is to refer the provided context and answer the user's question using the given context in 2-3 words, no more then 50words. 
    If the answer cannot be found in the context, simply provide output as "null", do not make the answer like 'The type of agreement mentioned in the given context is not specified' also if the query is as greetings (i.e.Hi, Hello,How are you?)simply state, "null".
    Please consider the synonyms of the question for example 'start date' can also be referred as 'effective date'.
    ---------------- {context}
    """
    # Create the chat prompt templates
    messages = [
        SystemMessagePromptTemplate.from_template(system_template),
        HumanMessagePromptTemplate.from_template("{question}")
    ]
    qa_prompt = ChatPromptTemplate.from_messages(messages)
    # Create conversational retrieval chain
    retriever = vectordb.as_retriever(search_kwargs={'k': 1})

    qa_chain = ConversationalRetrievalChain.from_llm(
        ChatOpenAI(temperature=0.2),
        retriever=retriever,
        return_source_documents=True,
        combine_docs_chain_kwargs={"prompt": qa_prompt}
    )
    return qa_chain


def custom_answer_query(query, qa_chain):
    chat_history = []
    # history_query = chat_history[-2:] if len(chat_history) >= 2 else chat_history[:]
        # If query is a list, process each element separately
    if isinstance(query, list):
        results_list = []
        for q, qa_chain in zip(query, qa_chain):
            results = qa_chain({'question': q, 'chat_history': chat_history})
            results_list.append(results)
            # print(results)

        answer_list = [res['answer'] for res in results_list]
        # print(answer_list)
        metadata_list = []
        for answer, results in zip(answer_list, results_list):
            if answer == "null":
                metadata_list.append('Not found')
            else:
                # metadata = []
                for document in results['source_documents']:
                    metadata_list.append(document.metadata)
                metadata_list.append(metadata_list[0])

        return answer_list, metadata_list



def main(file_paths):
    unique_id = str(uuid.uuid4())



    db_id_list = [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
        11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
        41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
        51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
        61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
        71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
        81, 82, 83, 84, 85, 86, 87, 88, 89
    ]

    terms = [
        "Term of service",
        "The ability to subcontract services",
        "Services",
        "Insurance coverage requirements",
        "Services",
        "Training of organization's employees",
        "Support, maintenance, and customer service",
        "Compliance with applicable laws, regulations, and regulatory guidance (explicit recognition of regulatory requirements)",
        "Terms governing the use of the organization's property, equipment, and staff",
        "The distribution of any required statements or disclosures to the organization's customers",
        "Fee Schedule",
        "Equipment and Software Responsibility",
        "Compensation Incentives",
        "Legal Fee Responsibility",
        "Audit and Regulatory Fee Responsibility",
        "Right to Audit",
        "Remediation Requirements are defined",
        "Audit Frequency",
        "Service level agreement requirements are defined",
        "Reports are provided by third party on compliance/non-compliance with service level agreement requirements",
        "Applicable Adherence to Regulatory Guidance",
        "Confidentiality and Security statement",
        "Breach Notification Timeframe",
        "Completion of Annual Security Questionnaire",
        "Minimum security standards",
        "Encryption Standards",
        "Results of Independent Code Reviews",
        "Employee Background Checks",
        "Penetration testing results",
        "Service Organization Control Reports 1",
        "Service Organization Control Reports 2",
        "Payment Card Industry Data Security Standard Report on Compliance / Attestation of Compliance",
        "International Standards Organization 27000 Compliance",
        "HITRUST CSF Compliance",
        "Escrow Agreement (source code)",
        "Licensing Rights",
        "Ownership of Generated Material",
        "Ownership of data",
        "Indemnification protecting the organization",
        "Termination Notification Requirements for bankruptcy",
        "Termination Notification Requirements for violation of law",
        "Termination Notification Requirements for insolvency",
        "Termination Notification Requirements for failure to meet performance standards or contractual obligations",
        "Merger and Acquisition Notification Timeframe and Requirements",
        "Timeframe for return of organization data and resources",
        "Dispute Resolution Responsibilities and Timeframes",
        "Damages Responsibility",
        "Limits on Liability",
        "Cybersecurity Insurance",
        "Notification requirements of changes in coverage",
        "Professional Liability",
        "General business insurance",
        "Handling of Customer Complaints",
        "Responsibilities",
        "Annual Disaster Recovery Test",
        "Business Continuity Plan",
        "Recovery Time Objectives",
        "Recovery Point Objectives",
        "Backup and Recovery",
        "Timeframe for reporting incident",
        "Assess the incident's nature and scope",
        "Conduct a reasonable investigation to identify information and systems accessed",
        "Determine the likelihood that the incident could result in substantial harm or inconvenience, or that the accessed information would be misused",
        "Promptly notify the organization of the incident details",
        "Promptly take appropriate steps to prevent further misuse of information",
        "Provide the organization with periodic updates on the investigation until resolved",
        "Provide remedies for the failure to meet incident response and reporting standards",
        "Detailed incident response and recovery metrics or specified the use of independent forensic expertise",
        "TSP’s responsibilities for assessing and responding to a potential incident, determining the potential effect on the FI and its customers, or the reporting and notification processes to regulatory and law enforcement authorities",
        "Requirement for subcontractors to report any incident affecting subcontract-related data",
        "Adverse Event",
        "Containment",
        "Cyber Event",
        "Materially Impact FI Client",
        "Misuse of Information",
        "Potential Breach",
        "Security Breach or Violation",
        "Significant Disruption",
        "Substantial Harm or Inconvenience",
        "Timely Notification",
        "Unauthorized Access",
        "Incentive Compensation",
        "Require third party to require subcontractors to have supply chain protection",
        "Data Storage and Transit Location",
        "Choice of Law and Jurisdiction",
        "Use of subcontractors",
        "Notification Requirements of changes in subcontractors use",
        "Restrictions on the use of foreign Service Providers",
        "Supply chain is protection requiring the third party to comply with a list of controls",
        "Secure coding practices and training for developers/programmers"
    ]

    description_terms = [
        "How long is the contract in effect?",
        "The third party should specify if they subcontract critical services that impact performance.",
        "Purchasers should understand which types of insurance the third party carries to protect products and services.",
        "What are the services the third party is providing?",
        "Specifies if the implementation of the product or service will require the purchaser's employees to be trained.",
        "Details how the product/service will be supported and maintained, such as software updates. The third party should also detail how customer service is provided.",
        "Third party should specify which laws and regulations they have to comply to. Some states have specific privacy laws, for example. Make sure the third party is aware and can comply.",
        "How is the purchaser's property, equipment and staff affected by the third party?",
        "Contract should specify how required disclosures are sent to the purchaser's customers and the frequency.",
        "Is there a fee schedule in the contract? Does it contain all fees and explain fee increases?",
        "How is equipment and/or software delivered and maintained?",
        "Does the vendor provide any compensation incentives?",
        "Which party pays legal fees in case of contract dispute?",
        "Which party is responsible for audit and regulatory fees that may be incurred?",
        "Grants the purchasing party the authority to conduct audits or assessments of the vendor's activities, records, and performance to ensure compliance with the terms of the contract.",
        "What are the requirements to remediate issues found during the audit?",
        "Third parties who provide audited documents such as SOC 2, should specify how often they are audited.",
        "This provision specifies the standards and metrics for services provided, such as quality, availability, and responsibilities. It sets clear expectations for service delivery.",
        "This requires a third party to regularly report on whether the service provider is meeting the agreed-upon service levels, highlighting any areas of non-compliance.",
        "It is important to understand which regulations a vendor is subject to and if they have had any issues with compliance.",
        "Has the vendor provided a statement that explains how your data is protected from a confidentiality and security standpoint?",
        "What is the maximum timeframe in which a vendor will report a breach of data?",
        "Will the vendor complete an annual security questionnaire? Some vendors may not or charge the client.",
        "Has the vendor shared their minimum security standards? Usually these are defined based on the organization's Information Security Program.",
        "If data is encrypted, what are the standards the vendor follows? Ideally these should be industry-accepted standards.",
        "What is the vendor's policy for sharing the results of independent code reviews? Typically these are SOC reports and should be shared with clients.",
        "Does the employer conduct background checks on employees? Also good to know is the type of background check(s).",
        "Does the vendor perform an annual penetration test? If so, do they share results, findings and remediation?",
        "Does the vendor have a SOC 1 report and do they share it?",
        "Does the vendor have a SOC 2 report and do they share it?",
        "If the vendor provides payment cards, do they have a PCI Attestation of Compliance?",
        "Is the vendor required to adhere to the ISO 27000 standards?",
        "Is the vendor required to adhere to the HITRUST CSF framework? Is the framework used for healthcare organizations.",
        "Source code escrow is the deposit of the source code of software with a third-party escrow agent. Escrow is typically requested by a party licensing software (the licensee), to ensure maintenance of the software instead of abandonment or orphaning.",
        "If applicable, the licensor will grant the licensee the right to use the brand name, trademark, patented technology, or ability to produce and sell goods owned by the licensor.",
        "Will discuss who has ownership of any work products produced during the lifetime of the contract.",
        "Discusses who has ownership of data that is stored by the third party during the lifetime of the contract.",
        "Indemnification is a legal agreement by one party to hold another party blameless - not liable - for potential losses or damages.",
        "Ensure the contract has language that specifies what happens if either party goes bankrupt and wants to end the contract. Typically termination is without notice.",
        "Ensure the contract has termination language in the case of either party violating applicable laws. It is also important to understand which country's laws are in effect if the vendor is headquartered in another country.",
        "Ensure there is language that specifies what the notification requirements are if the vendor becomes insolvent.",
        "What are the notification requirements if the vendor fails to meet performance standard (SLA) or contractual obligations.",
        "What are notification requirements if either party is subject to merger or acquisition?",
        "Upon termination of the contract, are there any provisions that speak to returning your organization's data and/or resources?",
        "In the event of a contract dispute, what is the timeframe to resolve and who is responsible?",
        "Damages are imposed if the court finds that a party breached a duty under contract or violated some right.",
        "A limitation of liability clause in a contract limits the amount of money or damages that one party can recover from another party for breaches or performance failures.",
        "Check to see if the third party provides cybersecurity insurance. Most third parties will provide proof of insurance as part of due diligence.",
        "This clause mandates that any alterations to the scope or extent of services, insurance coverage, or other contractual obligations must be promptly communicated to the relevant parties.",
        "This provision outlines the responsibility of a service provider to bear the cost of legal defense and damages in case their professional errors, omissions, or negligence cause harm to the client.",
        "It requires a party to maintain insurance policies like general liability, workers' compensation, and property insurance to protect against business-related risks.",
        "How are customer complaints handled by the vendor? Also check what the response time is by the vendor.",
        "The contract should clearly articulate the responsibilities of all parties.",
        "Does the vendor conduct an annual DR Test and do they share the results?",
        "Does the vendor have a Business Continuity Plan, is it updated at least annually and is it shared?",
        "RTO is the maximum tolerable length of time that a computer, system, network or application can be down after a failure or disaster occurs. Vendors should provide this information.",
        "RPO is the interval of time that might pass during a disruption before the quantity of data lost during that period exceeds the Business Continuity Plan's maximum allowable threshold or tolerance. Vendors should share this information.",
        "Has the vendor shared their backup and recovery policy? It is important to know how often your data is backed up and how long it will take to recover lost or corrupted data.",
        "Verify what the timeframe is for reporting a security incident.",
        "Ensure the contract speaks to what happens when an incident happens in terms of the type of incident and scope. Those terms will be important when dealing with incident response and remediation.",
        "In the event of a security breach, this clause obligates a party to investigate and identify what data and systems were compromised.",
        "This requires an assessment of the potential impact of a security incident, including the likelihood of harm or misuse of accessed information.",
        "This mandates immediate reporting to the concerned organization about the specifics of a security or contractual breach.",
        "This clause requires swift action to stop any ongoing or future misuse of compromised information.",
        "This ensures continuous communication about the progress and findings of an investigation following a breach or incident.",
        "This sets out the compensation or corrective actions required if the incident response or reporting obligations are not met.",
        "This provision demands specific metrics for evaluating incident response effectiveness and may require the involvement of independent forensic experts.",
        "This defines a Third-Party Service Provider's (TSP's) duties in managing incidents, assessing their impact, and guiding communication with authorities and affected parties.",
        "This obligates subcontractors to report security breaches or incidents that impact the data or services they handle.",
        "How does the vendor report and remediate adverse events?",
        "In the context of a security breach, this provision mandates measures to limit the extent of the breach and prevent further unauthorized access or damage.",
        "How does the vendor report and remediate cyber attacks on their systems?",
        "The vendor should report to the institution when material intrusions occur, the effect on the institution, and corrective action to respond to the intrusion.",
        "The vendor should provide a clause that explains how they handle the misuse of your data. Clients can take legal action and sue for damages where private information has been disclosed without their consent.",
        "A potential breach is a breach that hasn't actually happened yet but one of the parties expresses their intention to breach the contract's terms. Does the contract address this situation?",
        "What is the vendor's response and procedure if a security breach or violation occurs?",
        "What is the vendor's response and policy if a significant disruption occurs to their business?",
        "Does the vendor have contract language that details how they deal with the disclosure of sensitive information that could cause harm or inconvenience to the organization and its customers?",
        "Does the vendor provide timely notification in the event of breaches or other events?",
        "How does the vendor protect your data from unauthorized access?",
        "If this contract is not a fixed price contract, what is the acceptable and reasonable fees your organization will be expected to pay?",
        "This ensures that subcontractors also maintain adequate security measures throughout the supply chain.",
        "If the vendor is headquartered in a foreign country or has sub-service vendors in a foreign country, make sure to understand where your data resides and is transmitted.",
        "If the vendor is headquartered in a foreign country, it is important to understand which country's laws are in effect if there is a contract dispute.",
        "The third party should specify if they subcontract critical services that impact performance.",
        "For subcontractors that affect critical activities provided by the third party, they should have procedures to notify the purchaser if the subcontractor changes during the life of the contract.",
        "It is reasonable for the purchaser to restrict subcontractors to the current jurisdiction, i.e. not allow foreign entities.",
        "This clause specifies security and operational controls that third parties must adhere to, in order to protect the integrity and security of the supply chain.",
        "Does the contract include language t hat specifies what secure coding practices and training are in place for the developers of the application? This information may also be found in the SOC 2."
    ]

    results = {}
    vectordb = initialize_custom_conversational_chain(file_paths, unique_id)

    # Process queries in batches of 3
    batch_size = 1
    num_queries = len(terms)

    for start_index in range(0, num_queries, batch_size):
        # print("start",start_index)
        end_index = start_index + batch_size
        # print("end",end_index)

        batch_query_list = []
        batch_quchain_list = []
        # print("provision_terms",terms)
        for provision, description in zip(terms[start_index:end_index], description_terms[start_index:end_index]):
            # print(f"Provision: {provision}, Description: {description}")
            qachain = create_quchain(vectordb)
            batch_quchain_list.append(qachain)
            query = f"Extract answer for {provision} and this is the {description} for the query_field if the answer is available in the given document response only, yes if available or null for not available "
            batch_query_list.append(query)

        # for provision, description in zip(provision_terms[start_index:end_index], description_terms[start_index:end_index]):
        #     print(provision, description)
        #     qachain = create_quchain(vectordb)
        #     batch_quchain_list.append(qachain)
        #     query = f"Extract answer for {provision} and this is the {description} for the query_field if answer is available in given documet response yes else 'null' "
        #     # print(query)
        #     #query = f"Extract answer for {query_field} if available, and reformat the information in {data_type} format"
        #     batch_query_list.append(query)

        answer, metadata = custom_answer_query(batch_query_list, batch_quchain_list)

        for provision_terms ,db_query, a, m in zip(terms[start_index:end_index],db_id_list[start_index:end_index], answer, metadata):
            if not isinstance(m, dict):
                m = {'metadata': m}

            results[db_query] = {"provision_terms":provision_terms,"answer": a, "metadata": m}

            for key, value in results.items():
                # Check if 'metadata' key is present in the nested dictionary
                if 'metadata' in value and 'metadata' in value['metadata']:
                    # Replace {'metadata': 'Not found'} with {"metadata": "not_found"}
                    value['metadata']['page'] += 1
                    value['metadata'] = "not_found"
    return results



# file_paths = "/home/joshi/Downloads/Example 3.pdf"
# print(main(file_paths))
