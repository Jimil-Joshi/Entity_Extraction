import time

import entitiest_test
import provision_2_1
import entities_one_at_time
import provision_one_at_time
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.responses import UJSONResponse
from fastapi.middleware.cors import CORSMiddleware
import os
import json

app = FastAPI()

# Enable CORS
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class entities(BaseModel):
    file_paths: list[str]




app = FastAPI()

@app.post("/contract_analysis")

async def get_entities_and_provision(et: entities):
    start_time_api = time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    result_file_list = {}

    for file_path in et.file_paths:
        # Extract filename from the file path
        file_name = os.path.splitext(os.path.basename(file_path))[0]

        # Log start time for entities processing
        start_time_entities = time.strftime("%H:%M:%S.%f")[:-3]

        # Call entities processing function
        result_file_paths_entities = entitiest_test.main(file_path)

        # Log end time for entities processing
        end_time_entities = time.strftime("%H:%M:%S.%f")[:-3]

        # Log start time for provisions processing
        start_time_provisions = time.strftime("%H:%M:%S.%f")[:-3]

        # Call provisions processing function (uncomment when available)
        # result_file_paths_provisions = await provision_v1.main(et.file_path)

        # Log end time for provisions processing
        end_time_provisions = time.strftime("%H:%M:%S.%f")[:-3]

        # Dummy data for result_file_paths_provisions for testing purposes
        result_file_paths_provisions = provision_2_1.main(file_path)

        # Merge results
        merged_results = {"entities": result_file_paths_entities, "provisions": result_file_paths_provisions}

        # Write merged_results to a JSON file (filename.json)
        file_path_result = f"{file_name}.json"
        with open(file_path_result, "w") as json_file:
            json.dump(merged_results, json_file, indent=4)

        result_file_list[file_name + ".pdf"] = file_path_result
        end_time_api = time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        # Log timings into time_log.txt
        with open('time_log.txt', 'a') as log_file:
            log_file.write(
                f" Processing Type: API - Start: {start_time_api}, End: {end_time_api}\n")
            log_file.write(
                f"File: {file_name}, Processing Type: Entities - Start: {start_time_entities}, End: {end_time_entities}\n")
            log_file.write(
                f"File: {file_name}, Processing Type: Provisions - Start: {start_time_provisions}, End: {end_time_provisions}\n")

    return result_file_list



@app.post("/contract_analysis_internal")

async def get_entities_and_provision(et: entities):
    start_time_api = time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    result_file_list = {}

    for file_path in et.file_paths:
        # Extract filename from the file path
        file_name = os.path.splitext(os.path.basename(file_path))[0]

        # Log start time for entities processing
        start_time_entities = time.strftime("%H:%M:%S.%f")[:-3]

        # Call entities processing function
        result_file_paths_entities = entities_one_at_time.main(file_path)

        # Log end time for entities processing
        end_time_entities = time.strftime("%H:%M:%S.%f")[:-3]

        # Log start time for provisions processing
        start_time_provisions = time.strftime("%H:%M:%S.%f")[:-3]

        # Call provisions processing function (uncomment when available)
        # result_file_paths_provisions = await provision_v1.main(et.file_path)

        # Log end time for provisions processing
        end_time_provisions = time.strftime("%H:%M:%S.%f")[:-3]

        # Dummy data for result_file_paths_provisions for testing purposes
        result_file_paths_provisions = provision_one_at_time.main(file_path)

        # Merge results
        merged_results = {"entities": result_file_paths_entities, "provisions": result_file_paths_provisions}

        # Write merged_results to a JSON file (filename.json)
        file_path_result = f"{file_name}_oneattime.json"
        with open(file_path_result, "w") as json_file:
            json.dump(merged_results, json_file, indent=4)

        result_file_list[file_name + ".pdf"] = file_path_result
        end_time_api = time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        # Log timings into time_log.txt
        with open('time_log_internal.txt', 'a') as log_file:
            log_file.write(
                f" Processing Type: API - Start: {start_time_api}, End: {end_time_api}\n")
            log_file.write(
                f"File: {file_name}, Processing Type: Entities - Start: {start_time_entities}, End: {end_time_entities}\n")
            log_file.write(
                f"File: {file_name}, Processing Type: Provisions - Start: {start_time_provisions}, End: {end_time_provisions}\n")

    return result_file_list




if __name__ == "__main__":
    uvicorn.run("one_edpoint_api:app", host="0.0.0.0", port=5001, reload=True)