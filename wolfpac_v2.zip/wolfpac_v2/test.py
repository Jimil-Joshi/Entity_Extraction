import os
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import CharacterTextSplitter
import re

# Load environment variables from .env file
load_dotenv()

# Set the API key
api_key = os.getenv("OPENAI_API_KEY")

# Now you can use os.environ['OPENAI_API_KEY'] to access the API key in your script

def clean_text(text):
    # Remove special characters and newline characters using regular expressions
    cleaned_text = re.sub(r'[^\w\s]', '', text)
    cleaned_text = re.sub(r'\n', ' ', cleaned_text)
    return cleaned_text
def file_read(file_path):
    for file_path in file_path:
        loader = PyPDFLoader(file_path)
        documents = loader.load()
        # Split documents
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        text_splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=50)
        documents = text_splitter.split_documents(documents)
        for doc in documents:
            doc.page_content = clean_text(doc.page_content)
        with open(f"{file_name}_document.txt", "w") as file:
            file.write(str(documents))


print(file_read(["/home/joshi/Downloads/Tableau Software Site Usage Agreement.pdf","/home/joshi/Downloads/Contract Document v1.pdf","/home/joshi/Downloads/Example 1.pdf","/home/joshi/Downloads/Example 4.pdf","/home/joshi/Downloads/Example 3.pdf","/home/joshi/Downloads/Example2.pdf"]))